export interface ChatMessage {
  id: string
  user_id: string
  content: string
  model: string
  created_at: string
}
